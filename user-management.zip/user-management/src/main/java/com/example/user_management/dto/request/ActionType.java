package com.example.user_management.dto.request;

public enum ActionType {
    INSERTION, UPDATION;
}
