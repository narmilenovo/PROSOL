package com.example.user_management.dto.response;

import lombok.Data;

@Data
public class PrivilegeResponse {
    private Long id;
    private String name;
    private Boolean status;

}
