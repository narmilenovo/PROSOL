package com.example.user_management.dto.request;

public enum TokenType {
    BEARER
}
